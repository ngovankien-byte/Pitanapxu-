# Pita Nạp Xu - VietQR demo (1-click deploy)

## Mô tả
- Node.js + Express app tạo dynamic VietQR cho mỗi đơn hàng.
- Thiết kế để deploy nhanh trên Render (render.yaml) hoặc Railway (Dockerfile).

## Deploy lên Render (1-click)
1. Tạo repository trên GitHub và push toàn bộ folder này.
2. Đăng nhập Render -> New -> Web Service -> Connect GitHub -> Chọn repo.
3. Render sẽ tạo database Postgres miễn phí theo `render.yaml` và thiết lập `DATABASE_URL`.
4. Sau build, app chạy và bạn có link công khai.

## Chạy local (dev)
- Yêu cầu: Node.js, Postgres (hoặc dùng local-postgres). Set `DATABASE_URL` môi trường.
- Cài: `npm install`
- Chạy: `node server.js` (mặc định port 3000)
