const express = require('express');
const QRCode = require('qrcode');
const { Pool } = require('pg');
const bodyParser = require('body-parser');
const path = require('path');
const { generateVietQR } = require('uni-vqr');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATABASE_URL = process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/pita_db';
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false });

(async () => {
  // Create table if not exists
  const create = `CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    orderId VARCHAR(50),
    amount INTEGER,
    accountNumber VARCHAR(50),
    accountName VARCHAR(200),
    bankId VARCHAR(20),
    message VARCHAR(255),
    qrPayload TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    createdAt TIMESTAMP DEFAULT NOW()
  );`;
  await pool.query(create);
  console.log('DB init done');
})().catch(err=>{ console.error('DB init error', err); });

// Create order: expects { amount, coins (optional) }
app.post('/api/orders', async (req, res) => {
  try {
    const amount = parseInt(req.body.amount, 10) || 0;
    const orderId = 'ORD' + Date.now().toString().slice(-8);

    // These are demo values; change for production
    const bankId = process.env.BANK_ID || '970436'; // example
    const accountNumber = process.env.ACCOUNT_NUMBER || '0411001086628';
    const accountName = process.env.ACCOUNT_NAME || 'NGO VAN KIEN';
    const message = `Thanh toan ${orderId} - Zalo:0358247850`;

    // generate payload (VietQR/EMV) using uni-vqr
    const payload = generateVietQR({
      bankId,
      accountNumber,
      accountName,
      amount: amount > 0 ? amount : undefined,
      message
    });

    const qrDataUrl = await QRCode.toDataURL(payload, { width: 500 });

    await pool.query(
      'INSERT INTO orders (orderId, amount, accountNumber, accountName, bankId, message, qrPayload) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [orderId, amount, accountNumber, accountName, bankId, message, payload]
    );

    res.json({ orderId, qrDataUrl, payload });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Không thể tạo đơn' });
  }
});

app.get('/api/orders', async (req, res) => {
  try {
    const r = await pool.query('SELECT * FROM orders ORDER BY createdAt DESC');
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Không thể lấy danh sách' });
  }
});

app.post('/api/orders/:id/confirm', async (req, res) => {
  try {
    const id = req.params.id;
    await pool.query('UPDATE orders SET status = $1 WHERE id = $2', ['confirmed', id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Không thể xác nhận' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
